# Infrastructure diagram:

![image](../docs/infrastructure_overview.png)
