# DEPENDENCIES:

## 1. FE:

- angular: v8.2.14
- node: v16

## 2. BE:

- node: v16
- pg
- aws-sdk
- sequelize

## 3. AWS

1. S3:

- To host FE
- To storage image

2. RDS

- Database PostgreSQL

3. EB

- To host api

## 4. CICD

- Use circle
