# Pipeline overview:

![image](../docs/cicd_pipeline_overview.png)

## Pipeline build steps:

![image](../screenshots/cicleci_build_steps.png)

## Pipeline deploy steps:

![image](../screenshots/circleci_deploy_steps.png)
